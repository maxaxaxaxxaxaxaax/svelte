<script>
        async function query(data) {
          const response = await fetch('https://api-inference.huggingface.co/models/succinctly/text2image-prompt-generator', {
            headers: { Authorization: `Bearer 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` },
            method: 'POST',
            body: JSON.stringify(data),
          });
          const result = await response.json();
          return result;
        }
      
        let input = 'Hey, how is your day?';
        let output = '';
      
        const handleClick = async () => {
          const response = await query({ inputs: input });
          output = response[0].generated_text;
        };
      </script>
      
      <main>
        <h1>Stylish Text-to-Text Generator</h1>
        <p>
          This example uses the GPT-2 Inference API. More about it here: <a href="https://huggingface.co/gpt2">Huggingface GPT-2</a>
        </p>
        <div class="input">
          <label for="input">Query:</label>
          <textarea id="input" bind:value={input} rows="4"></textarea>
          <button on:click={handleClick}>Generate Text</button>
        </div>
        <div class="output">
          {#if output}
            <h2>Generated Text:</h2>
            <p>{output}</p>
          {/if}
        </div>
      </main>
      
      <style>
        body {
          font-family: Arial, sans-serif;
          margin: 0;
          padding: 0;
        }
      
        main {
          display: flex;
          flex-direction: column;
          align-items: center;
          padding: 20px;
        }
      
        h1 {
          text-align: center;
          margin-bottom: 20px;
        }
      
        p {
          text-align: center;
          margin: 8px 0;
        }
      
        .input {
          display: flex;
          flex-direction: column;
          align-items: flex-start;
          gap: 12px;
          margin-bottom: 20px;
        }
      
        label {
          font-weight: bold;
          font-size: 18px;
        }
      
        textarea {
          padding: 8px;
          border-radius: 4px;
          border: 1px solid #ccc;
          font-size: 14px;
          width: 400px;
          resize: vertical;
        }
      
        button {
          padding: 8px 16px;
          border-radius: 4px;
          background-color: #007bff;
          color: #fff;
          border: none;
          cursor: pointer;
          font-size: 16px;
        }
      
        .output {
          text-align: center;
        }
      
        h2 {
          font-size: 20px;
          margin-bottom: 10px;
        }
      </style>
      