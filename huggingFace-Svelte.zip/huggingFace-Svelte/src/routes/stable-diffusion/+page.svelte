<script>
        import { onMount } from 'svelte';
      
        let input = 'let me draw...';
        let output = null;
        let isLoading = false;
        let errorMessage = '';
      
        async function query(data) {
          try {
            isLoading = true;
            const response = await fetch('https://api-inference.huggingface.co/models/stabilityai/stable-diffusion-2-1', {
              headers: { Authorization: `Bearer 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` },
              method: 'POST',
              body: JSON.stringify(data),
            });
            const blob = await response.blob();
            return URL.createObjectURL(blob);
          } catch (error) {
            throw new Error('Something went wrong');
          } finally {
            isLoading = false;
          }
        }
      
        async function handleClick() {
          try {
            output = await query({ inputs: input });
          } catch (error) {
            errorMessage = error.message;
          }
        }
      
        onMount(() => {
          // Clean up the URL object when the component is unmounted
          return () => {
            if (output) {
              URL.revokeObjectURL(output);
            }
          };
        });
      </script>
      
      <main>
        <h1>Stylish Text-to-Image Generator</h1>
        <div class="input">
          <label for="input"></label>
          <input type="text" id="input" bind:value={input} />
          <button on:click={handleClick}>Send API Request</button>
        </div>
      
        {#if isLoading}
          <p>Loading...</p>
        {:else if output}
          <img src={output} alt="Generated Image" />
          <p>{input}</p>
        {:else if errorMessage}
          <p>{errorMessage}</p>
        {/if}
      </main>
      
      <style>
        body {
          font-family: Arial, sans-serif;
          margin: 0;
          padding: 0;
        }
      
        main {
          display: flex;
          flex-direction: column;
          align-items: center;
          padding: 20px;
        }
      
        h1 {
          text-align: center;
          margin-bottom: 20px;
        }
      
        .input {
          display: flex;
          align-items: center;
          gap: 12px;
          margin-bottom: 20px;
        }
      
        label {
          font-weight: bold;
        }
      
        input {
          padding: 8px;
          border-radius: 4px;
          border: 1px solid #ccc;
          font-size: 14px;
          width: 300px;
        }
      
        button {
          padding: 8px 16px;
          border-radius: 4px;
          background-color: #007bff;
          color: #fff;
          border: none;
          cursor: pointer;
        }
      
        p {
          text-align: center;
        }
      </style>
      