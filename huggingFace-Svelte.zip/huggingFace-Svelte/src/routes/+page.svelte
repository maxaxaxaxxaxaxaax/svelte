<h1>HiggingFace Demos</h1>

<p>this is the start of a collection of huggingFace examples</p>
